@extends('layouts.app')

@section('content')

<a href="/posts" class="btn btn-info">Go Back</a>
<h1>{{$post->title}}</h1>
<img style="width:50%" src="/storage/cover_images/{{$post->cover_image}}">
{{Form::hidden('_method', 'DELETE')}}
<hr>
{{Form::submit('Delete Picture', ['class' => 'btn btn-danger', 'PostsController@destroy', $post->cover_images ])}}

{!!Form::close()!!}
<br><br>

  
  
<div>
    <h3>{!!$post->body!!}</h3>
</div>
<hr>
<h3>Written on {{$post->created_at}} by {{$post->user->name}}</h3>
<hr>
@if(!Auth::guest())
@if(Auth::user()->id == $post->user_id)
<a href="/posts/{{$post->id}}/edit" class="btn btn-warning">Edit</a>
{!!Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'POST', 'class' => 'pull-right' ])!!}

{{Form::hidden('_method', 'DELETE')}}
<hr>
{{Form::submit('Delete', ['class' => 'btn btn-danger' ])}}

{!!Form::close()!!}
@endif
@endif
@endsection 